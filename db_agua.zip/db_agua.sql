-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.19 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para agua
CREATE DATABASE IF NOT EXISTS `agua` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `agua`;

-- Volcando estructura para tabla agua.alerta
CREATE TABLE IF NOT EXISTS `alerta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alerta_tipo_id` int(11) NOT NULL,
  `titulo` varchar(100) DEFAULT NULL,
  `mensaje` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_alerta_alerta_tipo1_idx` (`alerta_tipo_id`),
  CONSTRAINT `fk_alerta_alerta_tipo1` FOREIGN KEY (`alerta_tipo_id`) REFERENCES `alerta_tipo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.alerta: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alerta` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerta` ENABLE KEYS */;

-- Volcando estructura para tabla agua.alerta_entrega_correo
CREATE TABLE IF NOT EXISTS `alerta_entrega_correo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `alerta_id` int(11) NOT NULL,
  `entregado` int(11) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_alerta_entrega_users1_idx` (`user_id`),
  KEY `fk_alerta_entrega_alerta1_idx` (`alerta_id`),
  CONSTRAINT `fk_alerta_entrega_alerta1` FOREIGN KEY (`alerta_id`) REFERENCES `alerta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_alerta_entrega_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.alerta_entrega_correo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alerta_entrega_correo` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerta_entrega_correo` ENABLE KEYS */;

-- Volcando estructura para tabla agua.alerta_entrega_sistema
CREATE TABLE IF NOT EXISTS `alerta_entrega_sistema` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `alerta_id` int(11) NOT NULL,
  `entregado` int(11) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_alerta_entrega_users1_idx` (`user_id`),
  KEY `fk_alerta_entrega_alerta1_idx` (`alerta_id`),
  CONSTRAINT `fk_alerta_entrega_alerta10` FOREIGN KEY (`alerta_id`) REFERENCES `alerta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_alerta_entrega_users10` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.alerta_entrega_sistema: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alerta_entrega_sistema` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerta_entrega_sistema` ENABLE KEYS */;

-- Volcando estructura para tabla agua.alerta_tipo
CREATE TABLE IF NOT EXISTS `alerta_tipo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `por_correo` int(11) DEFAULT NULL,
  `por_sistema` int(11) DEFAULT NULL,
  `por_sms` int(11) DEFAULT NULL,
  `por_app` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.alerta_tipo: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `alerta_tipo` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerta_tipo` ENABLE KEYS */;

-- Volcando estructura para tabla agua.boleta
CREATE TABLE IF NOT EXISTS `boleta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta_id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL,
  `estado_pago_id` int(11) NOT NULL DEFAULT '1',
  `cliente_id` int(11) DEFAULT NULL,
  `correlativo` int(11) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `iva` int(11) DEFAULT NULL,
  `neto` int(11) DEFAULT NULL,
  `f_vencimiento` date DEFAULT NULL,
  `f_emision` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `emitida_sii` int(11) DEFAULT '0',
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cargo_cuenta1_idx` (`cuenta_id`),
  KEY `fk_cargo_periodo1_idx` (`periodo_id`),
  KEY `fk_boleta_estado_pago1_idx` (`estado_pago_id`),
  CONSTRAINT `fk_boleta_estado_pago1` FOREIGN KEY (`estado_pago_id`) REFERENCES `estado_pago` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cargo_cuenta1` FOREIGN KEY (`cuenta_id`) REFERENCES `cuenta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cargo_periodo1` FOREIGN KEY (`periodo_id`) REFERENCES `periodo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.boleta: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `boleta` DISABLE KEYS */;
REPLACE INTO `boleta` (`id`, `cuenta_id`, `periodo_id`, `estado_pago_id`, `cliente_id`, `correlativo`, `total`, `iva`, `neto`, `f_vencimiento`, `f_emision`, `emitida_sii`, `created_at`, `updated_at`) VALUES
	(1, 3, 15, 1, 1, NULL, 100, NULL, NULL, NULL, '2018-03-23 19:05:47', 0, '2018-03-24', '2018-03-24'),
	(2, 1, 15, 1, 1, NULL, 100, NULL, NULL, NULL, '2018-03-23 19:05:47', 0, '2018-03-24', '2018-03-24');
/*!40000 ALTER TABLE `boleta` ENABLE KEYS */;

-- Volcando estructura para tabla agua.boleta_detalle
CREATE TABLE IF NOT EXISTS `boleta_detalle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `boleta_id` int(11) NOT NULL,
  `servicio_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_boleta_detalle_boleta1_idx` (`boleta_id`),
  KEY `fk_boleta_detalle_servicio1_idx` (`servicio_id`),
  CONSTRAINT `fk_boleta_detalle_boleta1` FOREIGN KEY (`boleta_id`) REFERENCES `boleta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_boleta_detalle_servicio1` FOREIGN KEY (`servicio_id`) REFERENCES `servicio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.boleta_detalle: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `boleta_detalle` DISABLE KEYS */;
REPLACE INTO `boleta_detalle` (`id`, `boleta_id`, `servicio_id`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, '2018-03-24', '2018-03-24'),
	(2, 2, 2, '2018-03-24', '2018-03-24'),
	(3, 2, 3, '2018-03-24', '2018-03-24');
/*!40000 ALTER TABLE `boleta_detalle` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `apellido_paterno` varchar(100) DEFAULT NULL,
  `apellido_materno` varchar(100) DEFAULT NULL,
  `rut` varchar(100) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `habilitado` int(11) DEFAULT '1',
  `user_id` int(11) DEFAULT '1',
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.cliente: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
REPLACE INTO `cliente` (`id`, `nombre`, `apellido_paterno`, `apellido_materno`, `rut`, `direccion`, `email`, `habilitado`, `user_id`, `created_at`, `updated_at`) VALUES
	(1, 'Ricardo', 'Inostroza', 'Rebolledo', '15242854-5', 'Los manzanos 1, Puerto Varas', 'rinostrozareb@gmail.com', 1, 1, '2018-03-01', '2018-03-01'),
	(2, 'Ricardo', 'Inostroza', 're', '1-9', 'cd', 'rinostrozareb@gmail.com', 1, 1, '2018-03-03', '2018-03-03'),
	(14, 'Natalie', 'Leyton', 'Ahrens', '2-7', 'Los manzanos 2, Puerto Varas', 'natalie@gmail.com', 1, 6, '2018-03-04', '2018-03-04'),
	(15, '1', 'ytre', NULL, '1-95', NULL, '6t', 1, 7, '2018-03-07', '2018-03-07');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cliente_proyecto
CREATE TABLE IF NOT EXISTS `cliente_proyecto` (
  `cliente_id` int(11) NOT NULL,
  `proyecto_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`cliente_id`,`proyecto_id`),
  KEY `fk_clienteproyecto_proyecto1_idx` (`proyecto_id`),
  KEY `fk_clienteproyecto_cliente_idx` (`cliente_id`),
  CONSTRAINT `fk_clienteproyecto_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_clienteproyecto_proyecto1` FOREIGN KEY (`proyecto_id`) REFERENCES `proyecto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.cliente_proyecto: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `cliente_proyecto` DISABLE KEYS */;
REPLACE INTO `cliente_proyecto` (`cliente_id`, `proyecto_id`, `created_at`, `updated_at`) VALUES
	(1, 1, NULL, NULL),
	(1, 2, NULL, NULL),
	(1, 4, NULL, NULL),
	(2, 1, NULL, NULL),
	(2, 2, NULL, NULL),
	(14, 1, NULL, NULL),
	(14, 2, NULL, NULL);
/*!40000 ALTER TABLE `cliente_proyecto` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cuenta
CREATE TABLE IF NOT EXISTS `cuenta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `medidor_id` int(11) NOT NULL,
  `cuenta_estado_id` int(11) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cuenta_proyecto1_idx` (`proyecto_id`),
  KEY `fk_cuenta_cliente1_idx` (`cliente_id`),
  KEY `fk_cuenta_medidor1_idx` (`medidor_id`),
  KEY `fk_cuenta_cuenta_estado1_idx` (`cuenta_estado_id`),
  CONSTRAINT `fk_cuenta_cliente1` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuenta_cuenta_estado1` FOREIGN KEY (`cuenta_estado_id`) REFERENCES `cuenta_estado` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuenta_medidor1` FOREIGN KEY (`medidor_id`) REFERENCES `medidor` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuenta_proyecto1` FOREIGN KEY (`proyecto_id`) REFERENCES `proyecto` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.cuenta: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `cuenta` DISABLE KEYS */;
REPLACE INTO `cuenta` (`id`, `proyecto_id`, `cliente_id`, `medidor_id`, `cuenta_estado_id`, `direccion`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 2, 1, 1, 2, 'parcela 1', '2018-03-03', '2018-03-15', NULL),
	(3, 1, 1, 3, 1, 'parcela 2', '2018-03-07', '2018-03-15', NULL);
/*!40000 ALTER TABLE `cuenta` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cuentaservicio
CREATE TABLE IF NOT EXISTS `cuentaservicio` (
  `cuenta_id` int(11) NOT NULL AUTO_INCREMENT,
  `servicio_id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`cuenta_id`,`servicio_id`),
  KEY `fk_cuentaservicio_servicio1_idx` (`servicio_id`),
  KEY `fk_cuentaservicio_cuenta1_idx` (`cuenta_id`),
  CONSTRAINT `fk_cuentaservicio_cuenta1` FOREIGN KEY (`cuenta_id`) REFERENCES `cuenta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_cuentaservicio_servicio1` FOREIGN KEY (`servicio_id`) REFERENCES `servicio` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.cuentaservicio: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `cuentaservicio` DISABLE KEYS */;
REPLACE INTO `cuentaservicio` (`cuenta_id`, `servicio_id`, `created_at`, `updated_at`) VALUES
	(1, 2, '2018-03-15', '2018-03-15'),
	(1, 3, '2018-03-23', '2018-03-23'),
	(3, 1, '2018-03-15', '2018-03-15');
/*!40000 ALTER TABLE `cuentaservicio` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cuenta_estado
CREATE TABLE IF NOT EXISTS `cuenta_estado` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Determina el estado del servicio, los instalados se le cobra un valor, a los habilitados otro valor';

-- Volcando datos para la tabla agua.cuenta_estado: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `cuenta_estado` DISABLE KEYS */;
REPLACE INTO `cuenta_estado` (`id`, `nombre`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Instalado', '2018-03-03', '2018-03-03', NULL),
	(2, 'Habilitado', '2018-03-03', '2018-03-03', NULL),
	(3, 'Suspendido', '2018-03-03', '2018-03-03', NULL),
	(4, 'Retirado', '2018-03-03', '2018-03-03', NULL);
/*!40000 ALTER TABLE `cuenta_estado` ENABLE KEYS */;

-- Volcando estructura para tabla agua.cuenta_historial
CREATE TABLE IF NOT EXISTS `cuenta_historial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cuenta_id` int(11) NOT NULL,
  `cuenta_estado_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_servicio_historial_servicio1_idx` (`cuenta_id`),
  KEY `fk_servicio_historial_servicio_estado1_idx` (`cuenta_estado_id`),
  CONSTRAINT `fk_servicio_historial_servicio1` FOREIGN KEY (`cuenta_id`) REFERENCES `cuenta` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_servicio_historial_servicio_estado1` FOREIGN KEY (`cuenta_estado_id`) REFERENCES `cuenta_estado` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.cuenta_historial: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `cuenta_historial` DISABLE KEYS */;
/*!40000 ALTER TABLE `cuenta_historial` ENABLE KEYS */;

-- Volcando estructura para tabla agua.estado_pago
CREATE TABLE IF NOT EXISTS `estado_pago` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.estado_pago: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `estado_pago` DISABLE KEYS */;
REPLACE INTO `estado_pago` (`id`, `nombre`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Pendiente de pago', '2018-03-15', '2018-03-15', NULL),
	(2, 'Atrasada', '2018-03-15', '2018-03-15', NULL),
	(3, 'Pagada', '2018-03-15', '2018-03-15', NULL);
/*!40000 ALTER TABLE `estado_pago` ENABLE KEYS */;

-- Volcando estructura para tabla agua.lectura
CREATE TABLE IF NOT EXISTS `lectura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `periodo_id` int(11) DEFAULT NULL,
  `medidor_id` int(11) NOT NULL,
  `anterior` bigint(20) DEFAULT NULL,
  `actual` bigint(20) DEFAULT NULL,
  `diferencia` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lectura_medidor1_idx` (`medidor_id`),
  CONSTRAINT `fk_lectura_medidor1` FOREIGN KEY (`medidor_id`) REFERENCES `medidor` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.lectura: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `lectura` DISABLE KEYS */;
REPLACE INTO `lectura` (`id`, `periodo_id`, `medidor_id`, `anterior`, `actual`, `diferencia`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(10, 15, 1, 40, 45, '5', '2018-03-23', '2018-03-23', NULL),
	(11, 15, 1, 45, 50, '5', '2018-03-23', '2018-03-23', NULL),
	(12, 16, 1, 50, 55, '5', '2018-03-23', '2018-03-23', NULL),
	(13, 17, 1, 55, 60, '5', '2018-03-23', '2018-03-23', NULL),
	(14, 18, 1, 60, 65, '5', '2018-03-23', '2018-03-23', NULL),
	(16, 19, 1, 105, 140, '35', '2018-03-23', '2018-03-23', NULL);
/*!40000 ALTER TABLE `lectura` ENABLE KEYS */;

-- Volcando estructura para tabla agua.medidor
CREATE TABLE IF NOT EXISTS `medidor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serie` varchar(100) DEFAULT NULL,
  `medidor_modelo_id` int(11) NOT NULL,
  `lectura_inicial` int(11) DEFAULT NULL,
  `lectura_ultima` int(11) DEFAULT NULL,
  `asociado` int(11) DEFAULT '0',
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_medidor_medidor_modelo1_idx` (`medidor_modelo_id`),
  CONSTRAINT `fk_medidor_medidor_modelo1` FOREIGN KEY (`medidor_modelo_id`) REFERENCES `medidor_modelo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.medidor: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `medidor` DISABLE KEYS */;
REPLACE INTO `medidor` (`id`, `serie`, `medidor_modelo_id`, `lectura_inicial`, `lectura_ultima`, `asociado`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, '10021', 1, 10, 140, 1, '2018-03-03', '2018-03-23', NULL),
	(2, '10022', 2, 22, NULL, 0, '2018-03-03', '2018-03-03', NULL),
	(3, '5555555', 2, 10, NULL, 1, '2018-03-07', '2018-03-07', NULL),
	(4, '6666', 1, 3, 5, 0, '2018-03-08', '2018-03-08', NULL);
/*!40000 ALTER TABLE `medidor` ENABLE KEYS */;

-- Volcando estructura para tabla agua.medidor_modelo
CREATE TABLE IF NOT EXISTS `medidor_modelo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.medidor_modelo: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `medidor_modelo` DISABLE KEYS */;
REPLACE INTO `medidor_modelo` (`id`, `nombre`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'modelo 1', '2018-03-03', '2018-03-03', '2018-03-03'),
	(2, 'Modelo 2', '2018-03-03', '2018-03-03', '2018-03-03');
/*!40000 ALTER TABLE `medidor_modelo` ENABLE KEYS */;

-- Volcando estructura para tabla agua.medidor_periodo
CREATE TABLE IF NOT EXISTS `medidor_periodo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `medidor_id` int(11) NOT NULL,
  `periodo_id` int(11) NOT NULL,
  `consumo_promedio` bigint(20) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_medidor_periodo_medidor1_idx` (`medidor_id`),
  KEY `fk_medidor_periodo_periodo1_idx` (`periodo_id`),
  CONSTRAINT `fk_medidor_periodo_medidor1` FOREIGN KEY (`medidor_id`) REFERENCES `medidor` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_medidor_periodo_periodo1` FOREIGN KEY (`periodo_id`) REFERENCES `periodo` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.medidor_periodo: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `medidor_periodo` DISABLE KEYS */;
REPLACE INTO `medidor_periodo` (`id`, `medidor_id`, `periodo_id`, `consumo_promedio`, `created_at`, `updated_at`) VALUES
	(1, 1, 18, 5, '2018-03-23', '2018-03-23'),
	(3, 1, 19, 35, '2018-03-23', '2018-03-23'),
	(4, 3, 15, 30, '2018-03-24', '2018-03-24'),
	(5, 1, 15, 30, '2018-03-24', '2018-03-24');
/*!40000 ALTER TABLE `medidor_periodo` ENABLE KEYS */;

-- Volcando estructura para tabla agua.migrations
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.migrations: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
REPLACE INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2017_04_10_000000_create_users_table', 1),
	(2, '2017_04_10_000001_create_password_resets_table', 1),
	(3, '2017_04_10_000002_create_social_accounts_table', 1),
	(4, '2017_04_10_000003_create_roles_table', 1),
	(5, '2017_04_10_000004_create_users_roles_table', 1),
	(6, '2017_06_16_000005_create_protection_validations_table', 1),
	(7, '2017_06_16_000006_create_protection_shop_tokens_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando estructura para tabla agua.parametro
CREATE TABLE IF NOT EXISTS `parametro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) DEFAULT '0',
  `valor` varchar(250) DEFAULT '0',
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.parametro: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `parametro` DISABLE KEYS */;
REPLACE INTO `parametro` (`id`, `nombre`, `valor`, `created_at`, `updated_at`) VALUES
	(1, 'consumo_mensual_maximo', '30', '2018-03-13', '2018-03-13');
/*!40000 ALTER TABLE `parametro` ENABLE KEYS */;

-- Volcando estructura para tabla agua.password_resets
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.password_resets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Volcando estructura para tabla agua.periodo
CREATE TABLE IF NOT EXISTS `periodo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `mes` varchar(100) DEFAULT NULL,
  `anio` varchar(100) DEFAULT NULL,
  `activo_lectura` tinyint(1) DEFAULT '0',
  `activo_facturacion` tinyint(1) DEFAULT '0',
  `emitido` tinyint(1) DEFAULT '0',
  `desde` date DEFAULT NULL,
  `hasta` date DEFAULT NULL,
  `f_vencimiento_pago` date DEFAULT NULL,
  `f_vencimiento_corte` date DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.periodo: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `periodo` DISABLE KEYS */;
REPLACE INTO `periodo` (`id`, `nombre`, `mes`, `anio`, `activo_lectura`, `activo_facturacion`, `emitido`, `desde`, `hasta`, `f_vencimiento_pago`, `f_vencimiento_corte`, `created_at`, `updated_at`) VALUES
	(1, '052017', '05', '2017', 0, 0, 1, '2017-05-03', '2017-05-31', '2017-06-15', '2017-06-16', '2018-03-03', '2018-03-23'),
	(15, '062017', '06', '2017', 0, 0, 1, NULL, NULL, NULL, NULL, '2018-03-23', '2018-06-29'),
	(16, '072017', '07', '2017', 0, 1, 0, NULL, NULL, NULL, NULL, '2018-03-23', '2018-06-29'),
	(17, '082017', '08', '2017', 0, 0, 0, NULL, NULL, NULL, NULL, '2018-03-23', '2018-03-23'),
	(18, '092017', '09', '2017', 0, 0, 0, NULL, NULL, NULL, NULL, '2018-03-23', '2018-03-23'),
	(19, '102017', '10', '2017', 1, 0, 0, NULL, NULL, NULL, NULL, '2018-03-23', '2018-03-23'),
	(20, '112017', '11', '2017', 0, 0, 0, NULL, NULL, NULL, NULL, '2018-03-23', '2018-03-23');
/*!40000 ALTER TABLE `periodo` ENABLE KEYS */;

-- Volcando estructura para tabla agua.protection_shop_tokens
CREATE TABLE IF NOT EXISTS `protection_shop_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires` timestamp NOT NULL,
  `success_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cancel_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `success_url_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cancel_url_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `shop_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pst_unique` (`user_id`,`success_url`,`cancel_url`),
  KEY `protection_shop_tokens_number_index` (`number`),
  KEY `protection_shop_tokens_expires_index` (`expires`),
  CONSTRAINT `pst_foreign_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.protection_shop_tokens: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `protection_shop_tokens` DISABLE KEYS */;
REPLACE INTO `protection_shop_tokens` (`id`, `user_id`, `number`, `expires`, `success_url`, `cancel_url`, `success_url_title`, `cancel_url_title`, `shop_url`) VALUES
	(2, 6, '6dd40975-787a-402a-b168-850842c926ff', '2018-03-07 18:26:04', 'http://agua.test/membership/clear-cache?dest=http%3A%2F%2Fagua.test%2Fmembership', 'http://agua.test/membership', 'Return to Laravel 5 Boilerplate', 'Cancel and return to Laravel 5 Boilerplate', 'https://go.netlicensing.io/shop/v2/?shoptoken=6dd40975-787a-402a-b168-850842c926ff');
/*!40000 ALTER TABLE `protection_shop_tokens` ENABLE KEYS */;

-- Volcando estructura para tabla agua.protection_validations
CREATE TABLE IF NOT EXISTS `protection_validations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `ttl` timestamp NOT NULL,
  `validation_result` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user` (`user_id`),
  KEY `protection_validations_ttl_index` (`ttl`),
  CONSTRAINT `pv_foreign_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.protection_validations: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `protection_validations` DISABLE KEYS */;
REPLACE INTO `protection_validations` (`id`, `user_id`, `ttl`, `validation_result`) VALUES
	(1, 6, '2018-03-08 14:49:07', '{"LB-SUBSCRIPTION-PLAN":{"productModuleNumber":"LB-SUBSCRIPTION-PLAN","valid":true,"expires":"2018-03-08T17:49:07.694Z","productModuleName":"Membership Plan - Subscription","licensingModel":"Subscription"}}');
/*!40000 ALTER TABLE `protection_validations` ENABLE KEYS */;

-- Volcando estructura para tabla agua.proyecto
CREATE TABLE IF NOT EXISTS `proyecto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.proyecto: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
REPLACE INTO `proyecto` (`id`, `nombre`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Parcelacion los arrayanes', '2018-03-01', '2018-03-01', NULL),
	(2, 'Parcelacion Los Volcanes', '2018-03-03', '2018-03-03', '2018-03-03'),
	(4, 'Rincones de Aika', '2018-06-29', '2018-06-29', NULL);
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;

-- Volcando estructura para tabla agua.roles
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.roles: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
REPLACE INTO `roles` (`id`, `name`, `weight`) VALUES
	(1, 'administrator', 0),
	(2, 'authenticated', 0);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando estructura para tabla agua.servicio
CREATE TABLE IF NOT EXISTS `servicio` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `total` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- Volcando datos para la tabla agua.servicio: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `servicio` DISABLE KEYS */;
REPLACE INTO `servicio` (`id`, `nombre`, `total`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Cargo fijo sin consumo', 5000, '2018-03-15', '2018-03-15', NULL),
	(2, 'Cargo fijo con consumo', 15000, '2018-03-15', '2018-03-15', NULL),
	(3, 'Sobreconsumo 10 mt3', 5000, '2018-03-15', '2018-03-15', NULL);
/*!40000 ALTER TABLE `servicio` ENABLE KEYS */;

-- Volcando estructura para tabla agua.social_accounts
CREATE TABLE IF NOT EXISTS `social_accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_accounts_user_id_provider_provider_id_index` (`user_id`,`provider`,`provider_id`),
  CONSTRAINT `social_accounts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.social_accounts: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `social_accounts` ENABLE KEYS */;

-- Volcando estructura para tabla agua.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `confirmation_code` char(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.users: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `name`, `email`, `password`, `active`, `confirmation_code`, `confirmed`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
	(1, 'Admin', 'rinostrozareb@gmail.com', '$2y$10$.tJRobaJIGwZ.GliNi2bLOjJck4jlHcbn5UHUXDUHktNv82FuuZYK', 1, 'b3c69bb4-41b4-445d-a3dc-f3b598ee478a', 1, 'tjd2UMfWMmyzfsw94oz33KRODY7dR2Fn0IKqS38iVkIYFp8CIXwYle4mkmgQ', '2018-03-01 15:08:19', '2018-03-01 15:08:19', NULL),
	(2, 'Cliente', 'cliente@actus.cl', '$2y$10$D2wEc9ZsRC3j3Lezao1Z9eDkzfbbSoYijbZV0ApFyJZ8cC2UIVUNS', 1, '88909b2f-bd14-428c-9972-c760c3573025', 1, 'X1jNVBmDRAIaf7RdpepVVDQ90IJiUq9p7OV05bRiCciyVvav1aGSuYGKCSeN', '2018-03-01 15:08:19', '2018-03-01 15:08:19', NULL),
	(6, 'Natalie Leyton Ahrens', 'natalie@gmail.com', '$2y$10$MfQRGTPc7ifdqeVjRsSjK.LUFoKfv.n4/9iMwjsvlKJtrV.61uNIS', 1, '6fc4e735-63b4-4ad5-9c37-80b27064237b', 1, 'EIdmx4PVZSRT2kTF74J5KhY1YSzo5Lfa6YTWDq0moibfV785kNRzcV8v6ox8', '2018-03-03 21:47:27', '2018-03-03 21:47:27', NULL),
	(7, '1 ytre ', '6t', '$2y$10$G09QWMz4G7MFhnQHoJAXHehYG3vGRpbueYVpWYCaHkcEBEvgHYOii', 1, '831a6e5b-7945-4422-875d-3242f8dacdd5', 0, NULL, '2018-03-07 18:20:06', '2018-03-07 18:20:06', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Volcando estructura para tabla agua.users_roles
CREATE TABLE IF NOT EXISTS `users_roles` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `users_roles_user_id_role_id_unique` (`user_id`,`role_id`),
  KEY `foreign_role` (`role_id`),
  CONSTRAINT `foreign_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `foreign_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Volcando datos para la tabla agua.users_roles: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
REPLACE INTO `users_roles` (`user_id`, `role_id`) VALUES
	(1, 1),
	(1, 2),
	(2, 2),
	(6, 2),
	(7, 2);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
